//
//  ViewController.swift
//  Animate
//
//  Created by Student on 11/26/19.
//  Copyright © 2019 Student. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    var scaleFactor: CGFloat = 2
    var angle: Double = 180
    var boxView: UIView?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let frameRect = CGRect(x: 20, y: 20, width: 45, height: 45)
        boxView = UIView(frame: frameRect)
        boxView?.backgroundColor = UIColor.blue
        view.addSubview(boxView!)
        
    }
    
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        let touch = touches.first!
        let location = touch.location(in: view)
        UIView.animate(withDuration: 2.0, delay: 0.0, options: [.curveEaseInOut], animations: {
            let scaleTrans = CGAffineTransform(scaleX: self.scaleFactor, y: self.scaleFactor)
            let rotateTrans = CGAffineTransform(rotationAngle: CGFloat(self.angle * Double.pi / 180))
            self.boxView!.transform = scaleTrans.concatenating(rotateTrans)
            self.angle = (self.angle == 180) ? 360 : 180
            self.scaleFactor = (self.scaleFactor == 2) ? 1 : 2
            self.boxView!.center = location
            
        }, completion: nil)
        
    }


}

