//
//  ViewController.swift
//  CoreLocationExample
//
//  Created by Student on 10/17/19.
//  Copyright © 2019 Student. All rights reserved.
//

import UIKit
import CoreLocation
class ViewController: UIViewController, CLLocationManagerDelegate{
    
    var locationManager = CLLocationManager()
    var location : CLLocation?
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if CLLocationManager.locationServicesEnabled(){
            locationManager.requestAlwaysAuthorization()
            
        }
        //more accurate it gonna be the more battery would be used
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.startUpdatingLocation()
        locationManager.delegate = self
    }
    
    //MARK:- CLLocation Manater Delegate Methods
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        location = locations.last
        print("\(String(describing: location))")
    }
    
    func locationManager(_ manager:CLLocationManager, didFailWithError error:Error){
        let errorAlert = UIAlertController(title: "Error", message: "Failed to get your location", preferredStyle: .alert)
        let OKAction = UIAlertAction(title: "OK", style: .default, handler: nil)
        errorAlert.addAction(OKAction)
        present(errorAlert, animated:true){
            //ignore
        }
    }
    
    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
        //switch need to exhausted
        switch status {
        case .authorizedAlways:
            locationManager.startUpdatingLocation()
        case .notDetermined:
            locationManager.requestAlwaysAuthorization()
        case .authorizedWhenInUse, .restricted, .denied:
            let alertController  = UIAlertController(title: "Background Location Access Disabled", message: "we need to keep updating your location for this app. Open this app's settings and set location access to 'Always'", preferredStyle: .alert)
            let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
            alertController.addAction(cancelAction)
            
            let openAction = UIAlertAction(title: "Open Settings", style: .default){
                (acion) in
                if let url = URL(string: UIApplication.openSettingsURLString){
                    UIApplication.shared.open(url, options: [:], completionHandler: nil)
                }
            }
            alertController.addAction(openAction)
            present(alertController,animated: true)
        @unknown default:
            fatalError()
        }//switch
        
    }//locationManager

}

