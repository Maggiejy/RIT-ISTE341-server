//
//  TipCalculatorModel.swift
//  TipCalculator
//
//  Created by Bryan French on 7/23/15.
//  Copyright (c) 2015 Bryan French. All rights reserved.
//

import Foundation
class TipCalculatorModel {
    var total: Double
    var taxPct: Double
    //computed property
    var subtotal: Double {
        get {
             total/(taxPct + 1)
        }
    }
    
    init(total: Double, taxPct: Double) {
        self.total = total
        self.taxPct = taxPct
    }
    
    func calcTipWith(tipPct: Double) ->Double {
        return subtotal * tipPct
    }
    
    func returnPossibleTips()->Dictionary<Int,(tipAmt:Double,total:Double)>{
        let possibleTips=[0.15,0.18,0.20]

        var retval = [Int:(Double,Double)]()
        for possibleTip in possibleTips {
            let intPct = Int(possibleTip * 100)
            let tip = calcTipWith(tipPct: possibleTip)
            let newTotal = subtotal + tip
            retval[intPct]=(tip,newTotal)
        }
        return retval
    }
}
