//
//  ViewController.swift
//  DrawMailer
//
//  Created by Student on 12/3/19.
//  Copyright © 2019 Student. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var customView: CustomView!
    @IBAction func sharePicture(){
        let image = customView.createImageFromContext()
        let message = "Here's a greate drawing!"
        let postItems = [message,image] as [Any]
        //let postItems = [message] as [Any]
        let activityVC = UIActivityViewController(activityItems: postItems, applicationActivities: nil)
        present(activityVC,animated: true,completion: nil)
    }
    @IBAction func savePicture(){
        let image = customView.createImageFromContext()
        UIImageWriteToSavedPhotosAlbum(image, self, #selector(image(_:didFinishSavingWithError:contextInfo:)), nil)
    }
    //Alert for saving image
    @objc func image(_ image: UIImage, didFinishSavingWithError error: Error?, contextInfo: UnsafeRawPointer) {
        if let error = error {
            // we got back an error!
            let ac = UIAlertController(title: "Save error", message: error.localizedDescription, preferredStyle: .alert)
            ac.addAction(UIAlertAction(title: "OK", style: .default))
            present(ac, animated: true)
        } else {
            let ac = UIAlertController(title: "Saved!", message: "The image is saved!.", preferredStyle: .alert)
            ac.addAction(UIAlertAction(title: "OK", style: .default))
            present(ac, animated: true)
        }
    }
    @IBAction func cls(){
        print("Clear the screen")
        customView?.cls()
    }

    @IBAction func undo(){
        print("undo last draw")
        customView?.undo()
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

