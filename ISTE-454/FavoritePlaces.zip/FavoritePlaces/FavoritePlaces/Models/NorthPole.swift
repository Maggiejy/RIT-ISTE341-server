//
//  NorthPole.swift
//  FavoritePlaces
//
//  Created by Bryan French on 10/24/19.
//  Copyright © 2019 Bryan French. All rights reserved.
//

import Foundation
import CoreLocation
import MapKit

class NorthPole: NSObject, MKAnnotation {
    var coordinate: CLLocationCoordinate2D {
            return CLLocationCoordinate2DMake(80, 0)
    }
    
    //optional
    var title: String? {
        return "The North Pole"
    }
    
    var subtitle: String? {
        return "Santa's Workshop"
    }

}
