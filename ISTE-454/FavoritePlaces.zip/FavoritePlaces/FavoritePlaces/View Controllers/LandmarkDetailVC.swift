//
//  LandmarkDetailVC.swift
//  FavoritePlaces
//
//  Created by Student on 11/7/19.
//  Copyright © 2019 Bryan French. All rights reserved.
//

import UIKit

class LandmarkDetailVC: UITableViewController {
    var landmark: Landmark!
    var delegate: ZoomingProtocol? //optional
    
    
    let LANDMARK_NAME_SECTION = 0
    let LANDMARK_STATE_SECTION = 1
    let LANDMARK_COORDINATES_SECTION = 2

    override func viewDidLoad() {
        super.viewDidLoad()

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 3
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return 1
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell: UITableViewCell? = tableView.dequeueReusableCell(withIdentifier: "reuseIdentifier")
        //create programmatically instead of using storyboard
        if cell == nil{
            cell = UITableViewCell(style: .default, reuseIdentifier: "reuseIdentifier")
        }
        // Configure the cell...
        switch indexPath.section {
        case LANDMARK_NAME_SECTION:
            cell!.textLabel?.text = landmark.name
        case LANDMARK_STATE_SECTION:
            cell!.textLabel?.text = landmark.state
        case LANDMARK_COORDINATES_SECTION:
            cell!.textLabel?.text = "Latitude: \(landmark.coordinate.latitude), Longitude: \(landmark.coordinate.longitude)"
        default:
            //shouldn't get here
            break;
        }
        return cell!
    }
    
    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        var title = ""
        switch section {
           case LANDMARK_NAME_SECTION:
               title = "Landmark Name"
           case LANDMARK_STATE_SECTION:
               title = "Landmark State"
           case LANDMARK_COORDINATES_SECTION:
               title = "Landmark Coordinates"
           default:
               //shouldn't get here
               break;
        }
        return title
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        var msg = ""
        switch indexPath.section {
           case LANDMARK_NAME_SECTION:
               msg = "You tapped Landmark Name"
           case LANDMARK_STATE_SECTION:
               msg = "You tapped Landmark State"
           case LANDMARK_COORDINATES_SECTION:
               msg = "You tapped Landmark Coordinates"
                //not the best way
                //(tabBarController?.viewControllers![0] as! MapVC).zoomOn(annotation: landmark)
                //better way
               //mapVC.zoomOn(annotation: landmark)
                //beter still
               delegate?.zoomOn(annotation: landmark)
           default:
               //shouldn't get here
               break;
        }
//        let alert = UIAlertController(title: "Tapped A Row", message: msg, preferredStyle: .alert)
//        let OKAction = UIAlertAction(title: "OK", style: .default, handler: nil)
//        alert.addAction(OKAction)
//        present(alert,animated: true)
//
//        tableView.deselectRow(at:indexPath, animated: true)
    }
    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
