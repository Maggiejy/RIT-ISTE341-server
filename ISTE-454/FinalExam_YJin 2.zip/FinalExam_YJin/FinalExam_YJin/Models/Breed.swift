//
//  Breed.swift
//  FinalExam_YJin
//
//  Created by Student on 12/5/19.
//  Copyright © 2019 Student. All rights reserved.
//

import Foundation
class Breed{
    private var name: String = ""
    private var description: String = ""
    var title:String?{
        get{
            return name
        }
    }
    func getName() -> String{
        return name
    }
    func setName(name:String){
        self.name = name
    }
    func getDescription() -> String{
        return description
    }
    func setDescription(description:String){
        self.description = description
    }

    init(name:String,description:String){
        self.setName(name: name)
        self.setDescription(description: description)
    }
}
