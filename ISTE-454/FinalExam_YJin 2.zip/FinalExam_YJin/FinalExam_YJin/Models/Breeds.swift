//
//  Breeds.swift
//  FinalExam_YJin
//
//  Created by Student on 12/5/19.
//  Copyright © 2019 Student. All rights reserved.
//

import Foundation
class Breeds{
    var breedslist:[Breed] = []
}
