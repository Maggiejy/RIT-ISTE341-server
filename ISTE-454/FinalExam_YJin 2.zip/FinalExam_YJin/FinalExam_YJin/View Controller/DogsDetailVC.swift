//
//  DogsDetailVC.swift
//  FinalExam_YJin
//
//  Created by Student on 12/5/19.
//  Copyright © 2019 Student. All rights reserved.
//

import UIKit

class DogsDetailVC: UIViewController {
    var breed:Breed!
    var ttl:String!
    var desc:String!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = ttl
        //add UITextView
        let textView:UITextView = UITextView()
        textView.text = desc
        textView.textColor = UIColor.black
        textView.backgroundColor = UIColor.white
        self.view.addSubview(textView)
        
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
