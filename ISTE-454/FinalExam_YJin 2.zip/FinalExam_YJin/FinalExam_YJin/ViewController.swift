//
//  ViewController.swift
//  FinalExam_YJin
//
//  Created by Student on 12/5/19.
//  Copyright © 2019 Student. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    var breedslist = Breeds()
    var breeds:[Breed]{
        get{
            return self.breedslist.breedslist
        }set(val){
            self.breedslist.breedslist = val
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

