//
//  ViewController.swift
//  Getter
//
//  Created by Student on 11/14/19.
//  Copyright © 2019 Student. All rights reserved.
//

import UIKit

class ViewController: UIViewController, XMLParserDelegate{

    @IBOutlet weak var textView: UITextView!
    @IBOutlet weak var spinner: UIActivityIndicatorView!
    
    var responseData: Data?
    
    var xmlParser = XMLParser()
    var itemArray:[String] = []
    //var urlString = "http://www.ist.rit.edu/~bdfvks/454/nationalParks.php?type=plist"
    var urlString = "https://www.rit.edu/ritnews/rss/topstories.rss"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        spinner.hidesWhenStopped = true
        
    }
    
    @IBAction func buttonClicked(){
        loadData()
    }
    func loadData(){
        let session = URLSession.shared
        let task = session.dataTask(with: URL(string: urlString)!,completionHandler: {(data,response,error) in
            //handle response
            print("received some data")
            
            //check the status code
            let httpResponse = response as! HTTPURLResponse
            print("response: \(httpResponse)")
            print("status code: \(httpResponse.statusCode)")
            print("headers: \(httpResponse.allHeaderFields)")
            
            //convert binary data to a string
            let string = String(data:data!, encoding: String.Encoding(rawValue: String.Encoding.ascii.rawValue))
            print("converted data:\(string)")
            self.responseData = data
            
            //we're on a background thread and we want to update the gui which has to be
            //on the foreground thread
            DispatchQueue.main.async(execute: {
                //this block executed asynchronously on the main thread
                self.parseData()
                self.spinner.stopAnimating()
                
            })
        })//data task
        spinner.startAnimating()
        //start the task
        task.resume()
    }//load data
    
    func parseData(){
        print("parseData: data=\(responseData)")
        let string = String(data:responseData!, encoding: String.Encoding(rawValue: String.Encoding.ascii.rawValue))
        textView.text = string
        
        let dir = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first
        //let fileURL = dir!.appendingPathComponent("data.plist")
        let fileURL = dir!.appendingPathComponent("data.xml")
        //try to write file
        do{
            try string?.write(to: fileURL, atomically: true, encoding: .utf8)
            //read it back in to a dictionary
//            let data = try Data.init(contentsOf: fileURL)
//            let dict = try PropertyListSerialization.propertyList(from: data, options: .mutableContainersAndLeaves, format: nil)
//            print("as a dictionary:\(dict)")
            
            //start the xml parsing
            xmlParser = XMLParser(data: responseData!)
            //parsing in separate class
            //parsing in the same class
            xmlParser.delegate = self
            //to speed up parsing
            xmlParser.shouldProcessNamespaces = false
            xmlParser.shouldResolveExternalEntities = false
            xmlParser.shouldReportNamespacePrefixes = false
            
            if !xmlParser.parse() {
                print("error in parsing \(xmlParser.parserError) line number = \(xmlParser.lineNumber)")
            }
        } catch{
            print("Problem writing to disk")
        }
    }
    
    // MARK: - XMLParser Delegate Methods
    func parserDidStartDocument(_ parser: XMLParser) {
        print("Parser started document")
    }
    func parserDidEndDocument(_ parser: XMLParser) {
        print("Parser ended document")
        print("itemArray count = \(itemArray.count)")
        print("itemArray = \(itemArray)")
    }
    func parser(_ parser: XMLParser, parseErrorOccurred parseError: Error) {
        print("Parser error: \(parseError)")
    }
    
    //called when a tag starts
    func parser(_ parser: XMLParser, didStartElement elementName: String, namespaceURI: String?, qualifiedName qName: String?, attributes attributeDict: [String : String] = [:]) {
        print("started element: \(elementName)")
    }
    
    func parser(_ parser: XMLParser, foundCharacters string: String) {
        print("Found charaters: \(string)")
    }
    
    func parser(_ parser: XMLParser, didEndElement elementName: String, namespaceURI: String?, qualifiedName qName: String?) {
        print("ended element: \(elementName)")
        if (elementName == "item"){
            itemArray.append(elementName)
        }
    }
}

