//
//  ViewController.swift
//  Greeter
//
//  Created by Student on 9/25/19.
//  Copyright © 2019 Student. All rights reserved.
//

import UIKit

class GreeterViewController: UIViewController, UITextFieldDelegate {
    
    @IBOutlet weak var inText: UITextField!
    @IBOutlet weak var outText: UILabel!
    
    @IBAction func sayHello(){
        inText.resignFirstResponder()
        if inText.text != "" {
            outText.text = String(format: "Hello %@ I am glad you stopped by today.", inText.text!)
        } else {
            outText.text = "Please insert your name."
        }
        inText.text = ""
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    
    //MARK:- TextFieldDelegate methods
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        //textField.resignFirstResponder()
        sayHello()
        return true
    }

}

