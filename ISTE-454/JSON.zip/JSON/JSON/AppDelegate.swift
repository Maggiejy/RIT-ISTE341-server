//
//  AppDelegate.swift
//  JSON
//
//  Created by Student on 11/19/19.
//  Copyright © 2019 Student. All rights reserved.
//

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {
    struct ParkStruct: Codable {
        var parkName: String
        var parkLocation: String
        var dateFormed: String
        var description: String
    }
    
    struct ParksStruct: Codable{
        var parks: [ParkStruct]
    }
    
    struct ParkStruct2: Codable {
        var parkName: String
        var state: String
        var dateFormed: String
        var descrip: String
        
        enum CodingKeys: String, CodingKey{
            case parkName
            case dateFormed
            case state = "parkLocation"
            case descrip = "description"
        }
    }
    
    struct ParksStruct2: Codable{
        var parks: [ParkStruct2]
    }

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        
        let endpoint = URL(string: "http://www.ist.rit.edu/~bdfvks/454/nationalParks.php?type=json")
        //blocking call to api
        let data = try? Data(contentsOf: endpoint!)
        
        //validate and serialize the response
        if let json = (try? JSONSerialization.jsonObject(with: data!, options: .mutableContainers)) as? [String:Any]{
            if let parks = json["parks"] as? Array<[String:Any]>{
                for park in parks{
                    print("**** \(park)")
                    let p = Park(json:park)
                    print("!!! park name: \(p.parkName)")
                    
                }
            }
            
        }
        //now using swiftjson
        let session = URLSession.shared
        let loadDataTask = session.dataTask(with: endpoint!){
            (data:Data?, response: URLResponse?, error: Error?) in
            if let responseError = error {
                //error occured - ddisplay an alert or something
                //careful - on a background thrad at this point
            } else if let httpResponse = response as? HTTPURLResponse {
                if httpResponse.statusCode != 200 {
                    let statusError = NSError(domain: "com.jin.y", code: httpResponse.statusCode, userInfo: [NSLocalizedDescriptionKey: "HTTP status code has an expected value"])
                    //display the error? - still background thread
                } else {
                    //now using swifty
                    let json = try! JSON(data: data!) //do catch would be better
                    if let parkName = json["parks"][0]["parkName"].string {
                        print("Using Swifty: \(parkName)")
                    }
                    //using decoder
                    let decoder = JSONDecoder()
                    let parkList = try! decoder.decode(ParksStruct.self, from: data!)
                    print(parkList)
                    //with property names not all matching
                    let parkList2 = try! decoder.decode(ParksStruct2.self, from: data!)
                    print(parkList2)
                    let pk = ParkStruct.init(parkName: "test name", parkLocation: "some state", dateFormed: "some date", description: "some description")
                    let encoder = JSONEncoder()
                    let parkData = try! encoder.encode(pk.self)
                    let parkStr = String.init(data: parkData, encoding: .utf8)
                    print("String from Park data is \(parkStr ?? "No Data")")
                
                }
            }
        }
        loadDataTask.resume()
        
        return true
    }

    // MARK: UISceneSession Lifecycle

    func application(_ application: UIApplication, configurationForConnecting connectingSceneSession: UISceneSession, options: UIScene.ConnectionOptions) -> UISceneConfiguration {
        // Called when a new scene session is being created.
        // Use this method to select a configuration to create the new scene with.
        return UISceneConfiguration(name: "Default Configuration", sessionRole: connectingSceneSession.role)
    }

    func application(_ application: UIApplication, didDiscardSceneSessions sceneSessions: Set<UISceneSession>) {
        // Called when the user discards a scene session.
        // If any sessions were discarded while the application was not running, this will be called shortly after application:didFinishLaunchingWithOptions.
        // Use this method to release any resources that were specific to the discarded scenes, as they will not return.
    }


}

