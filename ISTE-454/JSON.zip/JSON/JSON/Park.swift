//
//  Park.swift
//  JSON
//
//  Created by Student on 11/19/19.
//  Copyright © 2019 Student. All rights reserved.
//

import Foundation
class Park {
    var parkName: String
    var parkLocation: String
    var dateFormed: String
    var description: String
    
    init(json:[String:Any]){
        print("#### \(json)")
        parkName = json["parkName"] as? String ?? "Unknown"
        parkLocation = json["parkLocation"] as? String ?? "Unknown"
        dateFormed = json["dateFormed"] as? String ?? "Unknown"
        description = json["description"] as? String ?? "Unknown"
    }
    
}
