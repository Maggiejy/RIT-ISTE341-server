//
//  AnimatedView.swift
//  Khan
//
//  Created by Student on 11/26/19.
//  Copyright © 2019 Student. All rights reserved.
//

import UIKit
import AVFoundation

class AnimatedView: UIView {

    var khanChannel  = AVAudioPlayer()
    
    @IBOutlet weak var kirk:UIImageView!
    @IBAction func showHideKirk(sender: UISwitch){
        var frame = kirk.frame
        var alpha = 1.0
        var newColor = UIColor.blue
        if sender.isOn {
            frame.origin.y = 0 //show
            
        } else {
            frame.origin.y = -180 //hide
            alpha = 0.0
            newColor = UIColor.yellow
        }
        UIView.animate(withDuration: 0.5, delay: 0.0, options: [.curveLinear,.beginFromCurrentState], animations: {
            self.kirk.frame = frame
            self.kirk.alpha = CGFloat(alpha)
            self.superview?.backgroundColor = newColor
            if sender.isOn{
                self.playSound()
            } else {
                self.khanChannel.stop()
            }
        }, completion: nil)
        
    }
    
    func playSound(){
        if let khanSoundFilePath = Bundle.main.path(forResource: "khan", ofType: "mp3"){
            let khanURL = URL(fileURLWithPath: khanSoundFilePath)
            khanChannel = try! AVAudioPlayer(contentsOf: khanURL)
            khanChannel.play()
        }
        
    }

    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        //color the background
        UIColor.purple.set()
        UIRectFill(self.bounds)
    }
    
    func random() -> CGFloat{
        //return a random number between 0 and 1
        return CGFloat(Float(arc4random())/Float(UINT32_MAX))
    }

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        let newColor = UIColor(red: random(), green: random(), blue: random(), alpha: 1.0)
        superview?.backgroundColor = newColor
        super.touchesBegan(touches, with: event)
    }
    
    //to listen for motion events. the view must be the first responder to events
    override var canBecomeFirstResponder: Bool{
        return true
    }
    override func awakeFromNib() {
        self.becomeFirstResponder()
    }
    override func motionBegan(_ motion: UIEvent.EventSubtype, with event: UIEvent?) {
        let newColor = UIColor(red: random(), green: random(), blue: random(), alpha: 1.0)
        superview?.backgroundColor = newColor
    }

}
