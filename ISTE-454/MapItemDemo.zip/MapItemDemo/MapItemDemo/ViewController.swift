//
//  ViewController.swift
//  MapItemDemo
//
//  Created by Student on 11/12/19.
//  Copyright © 2019 Student. All rights reserved.
//

import UIKit
import CoreLocation
import MapKit
import Contacts

class ViewController: UIViewController {

    @IBOutlet weak var address: UITextField!
    @IBOutlet weak var city: UITextField!
    @IBOutlet weak var state: UITextField!
    @IBOutlet weak var zip: UITextField!
    
    var coords:CLLocationCoordinate2D!
    
    @IBAction func getDirections(_ sender: UIButton) {
        let getcoder = CLGeocoder()
        let addressString = "\(address.text!) \(city.text!) \(state.text!) \(zip.text!)"
        getcoder.geocodeAddressString(addressString, completionHandler: {(placemarks: [CLPlacemark]?,error: Error?) -> Void in
            
            if let placemark = placemarks?[0]{
                if let location = placemark.location{
                    self.coords = location.coordinate
                    self.showMap()
                }
            }
            
        })
    }
    
    func showMap(){
        let addressDict = [String(CNPostalAddressStreetKey): address.text!,
                           String(CNPostalAddressCityKey): city.text!,
                           String(CNPostalAddressStateKey): state.text!,
                           String(CNPostalAddressPostalCodeKey): zip.text!
        ]
        //for NPF-4 use park annotation.getLocation().coordinate
        //and nil for the address dictionary
        let place = MKPlacemark(coordinate: coords, addressDictionary: addressDict)
        let mapItem = MKMapItem(placemark: place)
        let options = [MKLaunchOptionsDirectionsModeKey:MKLaunchOptionsDirectionsModeDriving]
        mapItem.openInMaps(launchOptions: options)
        
    }
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

