//
//  Monster.swift
//  Monster_demo
//
//  Created by Student on 9/5/19.
//  Copyright © 2019 Yang JIn. All rights reserved.
//

import Foundation

//class is not inhearated from other class
class Monster: CustomStringConvertible, CustomDebugStringConvertible {
    var description: String {
        "Name: \(name), Number of Heads: \(numHeads)"
    }
    
    var debugDescription: String {
        "Name: \(name), Number of Heads: \(numHeads), Weapons: \(weapons), Undead: \(undead)"
    }
    
    //use let instead of var to make immuable
    //open: any module could be imported and same as public, public: overwritten or extended, default is internal, file private on could be access within the file, private is only could be used in the class
    private var numHeads: Int = 1 //private var numHeads = 1
    private var name: String = ""
    private var weapons: [String] = []
    private var undead: Bool
    
    //class 'Monster' has no initializers: create a property, need to be initialized or with a default value
    //desinated initializer: one classneed to have at least one,convinient initializer: is just easier, could only call convinient initializer within the same calss. Initializer has to call sub property first, and then the parent initializer. one  level by one level
    init(numHeads: Int, name: String, weapons: [String], undead: Bool) {
        //self.numHeads = numHeads
        //self.name = name
        //self.weapons = weapons
        self.undead = undead
        self.setNumHeads(numHeads)
        self.set(name:name)
        self.set(weapons: weapons)
    }
    convenience init() {
        self.init(numHeads:1, name:"Orc", weapons:[], undead: false)
        
    }
    
    func getNumHeads() -> Int{
        numHeads //return numHeads
    }
    func setNumHeads(_ _numHeads: Int){
        if _numHeads < 0  || _numHeads > 1000 {
            numHeads = 500
        } else {
            numHeads = _numHeads
        }
    }
    
    func getName() -> String{return name}
    func set(name: String){
        //could have multiple set function, need to have different parameter
        self.name = name
    }
    
    func getWeapons() -> [String] {return weapons}
    func set(weapons: [String]){
        self.weapons = weapons
    }
    
    func fearsomeRoar() {
        print("Roar!!")
    }
}

//2019/09/10 Into to Swift 2
//any variable could be optional, just add the ?behind the type
//non-optional type could not be nil
//unwrap the optional varabile with !
//weak reference are optional values
//if let will make weak reference a strong reference, but without is not produce a strong reference
//chaining: is only strong at chaining some.some?.somefunc()
//unowned reference: need to be issued to someone/smth

//strong reference is default
//weak references among objects wiht independent lifetimes, casual relation
//unowned references from owned objects with references back up to their owners

//initialization: every value must be initialized before it is used
//call sub property first and then parent property
//designated initialization could only call upward and only upward designated initialization,the convienient initializer could call same class designated initializer
//initializer is not inheritent by default,

//@lazy lazy property is the property is not calculated until it first apprears

//deinitialization deinit{closeFile(fileDescriptor)}


