//
//  ViewController.swift
//  MonsterDemo
//
//  Created by Student on 9/5/19.
//  Copyright © 2019 Yang JIn. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

