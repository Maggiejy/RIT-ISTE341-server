//
//  ViewController.swift
//  MyLocationMap
//
//  Created by Bryan French on 10/10/19.
//  Copyright © 2019 Bryan French. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation

class ViewController: UIViewController, MKMapViewDelegate {
    
    var locationManager: CLLocationManager?
    
    @IBOutlet weak var mapView: MKMapView!
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        locationManager = CLLocationManager()
        if CLLocationManager.locationServicesEnabled() {
            locationManager?.requestWhenInUseAuthorization()
        }
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        
        mapView.delegate = self
    }

    func mapView(_ mv: MKMapView, didUpdate userLocation: MKUserLocation) {
        
        let mkCoordinateRegion = MKCoordinateRegion(center: userLocation.coordinate, latitudinalMeters: 800, longitudinalMeters: 800)
        mapView.setRegion(mkCoordinateRegion, animated: true)
        
        //add an annotation
        let point = MKPointAnnotation()
        point.coordinate = userLocation.coordinate
        point.title = "Where am I?"
        point.subtitle = "I'm here!!"
        mv.addAnnotation(point)
        
        
    }

}

