//
//  Park.swift
//  NPF-3
//
//  Created by Student on 11/01/19.
//  Copyright © 2019 Student. All rights reserved.
//

import Foundation
import CoreLocation
import MapKit

class Park: NSObject, MKAnnotation {
    override var description: String {
        "{\nparkName: \(parkName) \nparkLocation: \(parkLocation) \ndateFormed: \(dateFormed) \narea: \(area) \nlink: \(link) \nlocation: \(String(describing: location)) \nimageLink: \(imageLink) \nimageName: \(imageName) \nimageSize: \(imageSize) \nimageType: \(imageType) \nparkDescription: \(parkDescription) \ncoordinate: \(coordinate) \ntitle: \(String(describing: title)) \nsubtitle: \(String(describing: subtitle)) }"
    }

    private var parkName : String = ""
    private var parkLocation : String = ""
    private var dateFormed : String = ""
    private var area : String = ""
    private var link : String = ""
    
    private var location: CLLocation? = nil
    private var imageLink: String = ""
    private var parkDescription: String = ""
    
    //new values from plist
    private var imageName: String = ""
    private var imageSize: String = ""
    private var imageType: String = ""
    
    var title : String? {
         get {
             return parkName
         }
    }
    var subtitle : String? {
         get {
             return parkLocation
         }
    }
    var coordinate: CLLocationCoordinate2D {
        get{
            return location!.coordinate
        }
    }
    
    func getParkName() -> String {
        return parkName
    }
    func set(name: String){
        let name = name.trimmingCharacters(in: .whitespacesAndNewlines)
        if name.count >= 3 && name.count <= 75 {
            parkName = name
        } else {
            parkName = "TBD"
            print("Bad value of \(name) in set(parkName): settign to TBD")
        }
    }
    func getParkLocation() -> String {
        return parkLocation
    }
    func set(parkLocation: String){
        let parkLocation = parkLocation.trimmingCharacters(in: .whitespacesAndNewlines)
        if parkLocation.count >= 3 && parkLocation.count <= 75 {
            self.parkLocation = parkLocation
        } else {
            self.parkLocation = "TBD"
            print("Bad value of \(parkLocation) in set(parkLocation): settign to TBD")
        }
    }
    func getDateFormed() -> String {
        return dateFormed
    }
    func set(dateFormed: String){
        self.dateFormed = dateFormed
    }
    func getArea() -> String {
        return area
    }
    func set(area: String){
        self.area = area
    }
    func getLink() -> String {
        return link
    }
    func set(link: String){
        self.link = link
    }
    func getLocation()->CLLocation?{
        return location
    }
    func set(location:CLLocation?){
        self.location = location
    }
    func getImageLink() -> String {
        return imageLink
    }
    func set(imageLink: String){
        self.imageLink = imageLink
    }
    func getParkDescription() -> String {
        return parkDescription
    }
    func set(description: String){
        self.parkDescription = description
    }
    func getImageName() -> String {
        return imageName
    }
    func set(imageName: String){
        self.imageName = imageName
    }
    func getImageSize() -> String {
        return imageSize
    }
    func set(imageSize: String){
        self.imageSize = imageSize
    }
    func getImageType() -> String {
        return imageType
    }
    func set(imageType: String){
        self.imageType = imageType
    }
    
    convenience override init(){
        self.init(parkName:"Unknown", parkLocation:"Unknown", dateFormed:"Unknown", area:"Unknown", link:"Unknown", location:nil, imageLink:"Unknown", imageName:"Unknown",  imageSize:"Unknown", imageType:"Unknown", parkDescription:"Unknown")
    }
    
    init(parkName:String, parkLocation:String, dateFormed:String, area:String, link:String, location:CLLocation?, imageLink:String, imageName:String, imageSize:String, imageType:String, parkDescription:String){
        super.init()
        self.set(name:parkName)
        self.set(parkLocation:parkLocation)
        self.set(dateFormed:dateFormed)
        self.set(area:area)
        self.set(link:link)
        self.set(location:location)
        self.set(imageLink:imageLink)
        self.set(imageName: imageName)
        self.set(imageSize: imageSize)
        self.set(imageType: imageType)
        self.set(description:parkDescription)
    }
}

