//
//  ViewController.swift
//  NPF-3
//
//  Created by Student on 11/1/19.
//  Copyright © 2019 Student. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation

class ViewController: UIViewController, MKMapViewDelegate, CLLocationManagerDelegate {
    var locationManager = CLLocationManager()
    var zoomedIn = false
    
    @IBOutlet weak var mapView: MKMapView!
    @IBOutlet weak var activityView: UIActivityIndicatorView!
    @IBAction func selectMapType(_ sender: UISegmentedControl!) {
        //check value and set the map type
         switch (sender.selectedSegmentIndex) {
               case 0:
                mapView.mapType = .standard
               case 1:
                mapView.mapType = .satellite
               default:
                mapView.mapType = .hybrid
        }
    }
    var parkList = Parks()
    var parks:[Park] {//front end for LandmarkList model object
        get {
            return self.parkList.parkList
        }
        set(val) {
            self.parkList.parkList = val
        }
    }
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        locationManager = CLLocationManager()
        if CLLocationManager.locationServicesEnabled() {
            locationManager.requestWhenInUseAuthorization()
        }
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        //locationManager.startUpdatingLocation()
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        activityView.isHidden = true
        activityView.hidesWhenStopped = true
        for park:Park in parks{
            mapView.addAnnotation(park)
        }
        mapView.delegate = self
        locationManager.delegate = self
        mapView.showsUserLocation = true
        
        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    override func viewWillAppear(_ animated: Bool) {
        for park: MKAnnotation in parks {
            mapView.addAnnotation(park)
        }
    }
    func startUpdating(){
        activityView.isHidden = false
        if (!activityView.isAnimating ){
            activityView.startAnimating()
        }
        locationManager.startUpdatingLocation()
        
    }
    func stopUpdating(){
        if (activityView.isAnimating ){
            activityView.stopAnimating()
        }
        activityView.isHidden = true
        locationManager.stopUpdatingLocation()
    }

    @IBAction func refresh(_ sender: UIBarButtonItem) {
        startUpdating()
       
        //add an annotation
        //let point = MKPointAnnotation()
        //point.coordinate = userLocation.coordinate
        //mapView.addAnnotation(point)
    }
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
         let location = locations.last
        if !zoomedIn {
           let region = MKCoordinateRegion(center: location!.coordinate, latitudinalMeters: 20000, longitudinalMeters: 20000)
            mapView.setRegion(region, animated: true)
            zoomedIn = true
        } else {
            zoomedIn = false
            mapView.showAnnotations(parks, animated: true)
        }
        stopUpdating()
       
    }
    //MARK: - MKMapViewDelegate Methods
    // This delegate method is called once for every annotation that is created.
    // If no view is returned by this method, then only the default pin is seen by the u
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        var view: MKPinAnnotationView
        let identifier = "Pin"
        if annotation is MKUserLocation {return nil}
        if annotation !== mapView.userLocation {
            //look for an existing view to reuse
            if let dequeuedView = mapView.dequeueReusableAnnotationView(withIdentifier: identifier) as? MKPinAnnotationView {
                //reuse it
                dequeuedView.annotation = annotation
                view = dequeuedView
                
            } else {
                //create a new one
                view = MKPinAnnotationView(annotation: annotation, reuseIdentifier: identifier)
                view.pinTintColor = MKPinAnnotationView.purplePinColor()
                view.animatesDrop = true
                view.canShowCallout = true
                let leftButton = UIButton(type: .infoLight)
                let rightButton = UIButton(type: .detailDisclosure)
                leftButton.tag = 0
                rightButton.tag = 1
                view.leftCalloutAccessoryView = leftButton
                view.rightCalloutAccessoryView = rightButton
            }
            return view
        }
        return nil
    }
    func mapView(_ mapView: MKMapView, annotationView view: MKAnnotationView,calloutAccessoryControlTapped control: UIControl) {
        let parkAnnotation = view.annotation as! Park
        switch control.tag {
            case 0: //left buttonif
                if let url = URL(string: parkAnnotation.getLink()){
                    UIApplication.shared.open(url, options: [:], completionHandler: nil)
                }
            case 1: //right button
                let coordinate = locationManager.location?.coordinate //make sure location manager has updated before trying to use
                let url = String(format: "http://maps.apple.com/maps?saddr=%f,%f&daddr=%f,%f", coordinate!.latitude,coordinate!.longitude,(((parkAnnotation.getLocation()?.coordinate.latitude)!)),((parkAnnotation.getLocation()?.coordinate.longitude)!))
                UIApplication.shared.open(URL(string: url)!, options: [:], completionHandler: nil)
            default:
                break
            
        }
        
    }
    
}

