//
//  Parks.swift
//  NPF-3
//
//  Created by Student on 11/4/19.
//  Copyright © 2019 Student. All rights reserved.
//

import Foundation
class Parks {
    var parkList : [Park] = []
}
