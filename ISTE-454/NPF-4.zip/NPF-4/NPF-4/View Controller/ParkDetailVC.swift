//
//  ParkDetailVC.swift
//  NPF-4
//
//  Created by Student on 11/26/19.
//  Copyright © 2019 Student. All rights reserved.
//
import Foundation
import UIKit

class ParkDetailVC: UITableViewController {

    var park: Park!
    var delegate: ZoomingProtocol? //optional
    
    let PARK_GEN_SECTION = 0
    let PARK_IMAGE_SECTION = 1
    let PARK_DESC_SECTION = 2
    let PARK_WIKI_SECTION = 3
    let PARK_MAP_SECTION = 4

    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.rowHeight = UITableView.automaticDimension
        tableView.estimatedRowHeight = 44
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 5
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if(section == PARK_GEN_SECTION){
            return 4
        } else {
            return 1
        }
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell: UITableViewCell? = tableView.dequeueReusableCell(withIdentifier: "reuseIdentifier")
        //create programmatically instead of using storyboard
        if cell == nil{
            cell = UITableViewCell(style: .default, reuseIdentifier: "reuseIdentifier")
        }
        cell!.textLabel?.textAlignment = .center
        // Configure the cell...
        switch indexPath.section {
        case PARK_GEN_SECTION:
            switch indexPath.row{
            case 0:
                cell!.textLabel?.text = park.title
            case 1:
                cell!.textLabel?.text = park.subtitle
            case 2:
                cell!.textLabel?.text = park.getArea()
            default:
                cell!.textLabel?.text = "Date Formed: \(park.getDateFormed())"
            }
        case PARK_IMAGE_SECTION:
            let link = park.getImageLink()
            let url = URL(string: link)
            if let data = try? Data(contentsOf: url!)
            {
                let imageView = UIImageView(image: UIImage(data: data))
                cell?.addSubview(imageView)
            }
        case PARK_DESC_SECTION:
            cell!.textLabel?.numberOfLines = 0
            cell!.textLabel?.textAlignment = .left
            cell!.textLabel?.text = park.getParkDescription()
        case PARK_WIKI_SECTION:
            cell!.textLabel?.text = park.getLink()
        case PARK_MAP_SECTION:
            cell!.textLabel?.text = "Show on Map"
        default:
            //shouldn't get here
            break;
        }
        return cell!
    }
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if indexPath.section == PARK_IMAGE_SECTION {
            return 250.0
        } else if indexPath.section == PARK_DESC_SECTION{
            return 200.0
        } else {
            return 44.0
        }
    }
    //MARK:- need to fix map zoomon
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        switch indexPath.section {
            case PARK_WIKI_SECTION:
                if let url = URL(string: park.getLink()){
                           UIApplication.shared.open(url, options: [:], completionHandler: nil)
                }
            case PARK_MAP_SECTION:
                delegate?.zoomOn(annotation: park)
           default:
               //shouldn't get here
               break;
        }
    }

    /*
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "reuseIdentifier", for: indexPath)

        // Configure the cell...

        return cell
    }
    */

    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
