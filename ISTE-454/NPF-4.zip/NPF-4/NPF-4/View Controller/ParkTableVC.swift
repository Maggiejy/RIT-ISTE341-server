//
//  ParkTableVCTableViewController.swift
//  NPF-4
//
//  Created by Student on 11/26/19.
//  Copyright © 2019 Student. All rights reserved.
//

import UIKit
import CoreLocation

class ParkTableVC: UITableViewController, CLLocationManagerDelegate {
    var locationManager = CLLocationManager()
    var location: CLLocation!
    var mapVC: MapVC!
    var parkList = Parks()
    var parks : [Park] { //front end for LandmarkList model object
        get {
            return self.parkList.parkList
        }
        set(val) {
            self.parkList.parkList = val
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        locationManager.delegate = self
        if (CLLocationManager.authorizationStatus() == CLAuthorizationStatus.authorizedWhenInUse ||
            CLLocationManager.authorizationStatus() == CLAuthorizationStatus.authorizedAlways){
            guard locationManager.location != nil else {
                return
            }
        }
        parks.sort(by:{$0.getParkName() < $1.getParkName()})
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return parks.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ParkCell", for: indexPath)

        // Configure the cell...
        let park = parks[indexPath.row]
        location = locationManager.location
        cell.textLabel?.text = park.title
        cell.detailTextLabel?.text = String(format: "Distance: %.02fmiles", park.getDistance(location: location))
        cell.accessoryType = .disclosureIndicator
        return cell
    }
    @IBAction func selectSortingType(_ sender: UISegmentedControl!) {
        //check value and set the map type
         switch (sender.selectedSegmentIndex) {
               case 0:
                parks.sort(by:{$0.getParkName() < $1.getParkName()})
                self.tableView.reloadData()
               case 1:
                parks.sort(by:{$0.getParkName() > $1.getParkName()})
                self.tableView.reloadData()
               default:
                parks.sort(by:{$0.getDistance(location:location) < $1.getDistance(location:location)})
                self.tableView.reloadData()
                
        }
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let park = parks[indexPath.row]
        let detailVC = ParkDetailVC(style: .grouped)
        detailVC.title = park.title
        detailVC.park = park
        detailVC.delegate = mapVC as? ZoomingProtocol
        navigationController?.pushViewController(detailVC, animated: true)
        
    }

    /*
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "reuseIdentifier", for: indexPath)

        // Configure the cell...

        return cell
    }
    */

    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */


}
