//
//  ViewController.swift
//  PlistTutorial
//
//  Created by Student on 9/24/19.
//  Copyright © 2019 Student. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var nameEntered: UITextField!
    @IBOutlet weak var homePhone: UITextField!
    @IBOutlet weak var workPhone: UITextField!
    @IBOutlet weak var cellPhone: UITextField!
    
    var personName = ""
    var phoneNumbers: [String] = []
    
    @IBAction func saveData(sender:UIButton){
        if let documentsURL = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first{
            let plistPath = documentsURL.appendingPathComponent("data.plist")
        
            personName = nameEntered.text!
            phoneNumbers = [homePhone.text!, workPhone.text!, cellPhone.text!]
        
            let plistDic:Dictionary<String,Any> = [
                "Name":personName,
                "Phones":phoneNumbers
            ]
            do {
                let plistData = try PropertyListSerialization.data(fromPropertyList: plistDic, format: .xml, options: 0)
        
                try plistData.write(to: plistPath)
            } catch {
                print(error)
            }
        }//if let
        
        view.endEditing(true)//dismiss the keyboard if you have multiple textfields
        
    }
    
    @IBAction func textFieldReturn(sender:UITextField){
        sender.resignFirstResponder()
    }
    
    @IBAction func deleteData(sender:UIButton) {
        let fileMgr = FileManager.default
        
        let dir = fileMgr.urls(for: .documentDirectory, in: .userDomainMask).first
        
        //show contents of the Documents directory
        print("\(String(describing: try? fileMgr.contentsOfDirectory(atPath: dir!.path)))")
        
        let fileURL = dir!.appendingPathComponent("data.plist")
        do {
            try fileMgr.removeItem(atPath: fileURL.path)
        } catch {
            print("Error deleting file: \(error)")
        }
        print("After deleting: \(String(describing: try? fileMgr.contentsOfDirectory(atPath: dir!.path)))")
    }
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        //load data from the plist: from main bundle if user hasn't saved any data yet
        //otherwise from documents folder
        
        if let documentPathURL = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first {
            
            //now have url for document directory
            var plistPath = documentPathURL.appendingPathComponent("data.plist").path
            
            
            
            //does a modified version exist
            if !FileManager.default.fileExists(atPath: plistPath){
                //no - use the default file we created
                plistPath = Bundle.main.path(forResource: "data", ofType: "plist")!
            }
            
            //we now have a path to a plist file - either the modified version or the original version
            print(plistPath)
            
            do{
                let data = try Data(contentsOf: URL(fileURLWithPath: plistPath))
                let temp = try PropertyListSerialization.propertyList(from: data, options: .mutableContainersAndLeaves, format: nil) as! [String:Any]
                
                print(temp)
                //get things from the dictionary might be empty, so we need to unwrap it
                //since the key of dictionary is any, so need to unwrap the dic aswell
                personName = temp["Name"]! as! String
                phoneNumbers = temp["Phones"]! as! [String]
                nameEntered.text = personName
                homePhone.text = phoneNumbers[0]
                workPhone.text = phoneNumbers[1]
                cellPhone.text = phoneNumbers[2]
                
            } catch {
                print(error)
            }
        }//if let
        
        
    }//viewDidLoad


}

