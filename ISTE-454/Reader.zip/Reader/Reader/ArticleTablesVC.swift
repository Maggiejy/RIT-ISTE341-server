//
//  ArticleTablesVC.swift
//  Reader
//
//  Created by Bryan French on 8/21/15.
//  Copyright (c) 2015 Bryan French. All rights reserved.
//

import UIKit

class ArticleTablesVC: UITableViewController {
    var articles:[Any] = []
    

    // MARK: -
    // MARK: Table view data source
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1;
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return articles.count
    }
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 150.0;
    }
    
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
    
        let CellIdentifier = "Cell"
        
        var cell: UITableViewCell? = tableView.dequeueReusableCell(withIdentifier: CellIdentifier)
        
        if !(cell != nil) {
            cell = UITableViewCell(style: .default, reuseIdentifier: CellIdentifier)
        }
        // Customize the cell with a UILabel and a UITextView
        let lab = UILabel(frame: CGRect(x: 20, y: 0, width: 260, height: 40))
        lab.numberOfLines = 0
        lab.tag = 100
        cell!.contentView.addSubview(lab)

        let tv = UITextView(frame: CGRect(x: 20,y: 50,width: 260,height: 100))
        tv.tag = 101
        tv.isEditable = false
        cell!.contentView.addSubview(tv)
        
        cell!.textLabel!.backgroundColor = UIColor.clear
    
        // Configure the cell...
        let title = (articles[(indexPath as NSIndexPath).row] as! [String:Any])["title"] as! String
        
        (cell!.contentView.viewWithTag(100) as! UILabel).text = title
        
        //let description = articles[indexPath.row]["description"]
        (cell!.contentView.viewWithTag(101) as! UITextView).text = title
    
        cell!.accessoryType = .disclosureIndicator;
        return cell!;
    }
    
    // MARK: -
    // MARK: Table view delegate
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        // Navigation logic may go here. Create and push another view controller.
        let detailVC = DetailVC(style: .grouped)
        detailVC.article = articles[indexPath.row] as? Dictionary<String, String>
        navigationController?.pushViewController(detailVC, animated: true)
    }
}
