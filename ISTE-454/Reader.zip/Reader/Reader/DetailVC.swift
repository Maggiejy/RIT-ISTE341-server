//
//  DetailVC.swift
//  Reader
//
//  Created by Bryan French on 8/21/15.
//  Copyright (c) 2015 Bryan French. All rights reserved.
//

import UIKit

class DetailVC: UITableViewController {
    
    var article : Dictionary<String,String>!

    override func viewDidLoad() {
        super.viewDidLoad()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        return 2
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if (indexPath as NSIndexPath).section == 0 {
            return 64.0
        } else {
            return 144.0
        }
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let CellIdentifier = "Cell"
        
        var cell: UITableViewCell? = tableView.dequeueReusableCell(withIdentifier: CellIdentifier)
        
        if !(cell != nil) {
            cell = UITableViewCell(style: .default, reuseIdentifier: CellIdentifier)
        }


        if ((indexPath as NSIndexPath).section == 0) {
            cell?.textLabel!.text = article["title"]
        }
        if ((indexPath as NSIndexPath).section == 1) {
            cell?.textLabel!.text = article["description"] 
            cell?.textLabel!.numberOfLines = 8
        }// Configure the cell...

        return cell!
    }
}
