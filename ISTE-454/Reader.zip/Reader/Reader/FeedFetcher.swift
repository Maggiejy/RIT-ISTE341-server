//
//  FeedFetcher.swift
//  Reader
//
//  Created by Bryan French on 8/20/15.
//  Copyright (c) 2015 Bryan French. All rights reserved.
//

import Foundation
import UIKit

let mySpecialNotificationKey = "com.french.bryan.specialNotificationKey"

protocol FeedFetcherDelegate {
    
    func feedFetcher(_ feedFetcher: FeedFetcher, feed: [Any])
    
}

class FeedFetcher: NSObject, XMLParserDelegate {
    var xmlParser : XMLParser!
    var itemArray : [Dictionary<String,String>] = []
    var urlString = ""
    var responseData : Data!
    var urlSession : URLSession!
    var task : URLSessionDataTask!
    var feedDelegate : FeedFetcherDelegate!
    var alertDelegate : UIAlertViewDelegate!
    //
    var currentItemDict : Dictionary<String,String>!
    var currentElement = ""
    var currentTitle = ""
    var currentDate = ""
    var currentSummary = ""
    var currentLink = ""
    
    // MARK: -
    // MARK: Initialization
    // Designated Initializer
    init(URL value:String) {
        super.init()
        urlString = value;
        loadData()
    }
    
    override init() {
        fatalError("Invalid initializer. Call initWithURL(URL value : String) instead!")
    }
    
    // MARK: -
    // MARK: Helper methods
    func loadData() {
        let session = URLSession.shared
        let task = session.dataTask(with: URL(string: urlString)!, completionHandler: {(data, reponse, error) in
            
            //cast NUSURLResponse to NSHTTPURLResponse
            let httpResponse = reponse as! HTTPURLResponse
            let statusCode = httpResponse.statusCode
           
            if error == nil && statusCode == 200 {
                //handle response
                self.responseData = data
                self.parseData()
            } else {
                self.urlSession.invalidateAndCancel()
                let errorString = "Unable to connect to \(self.urlString)"

                NotificationCenter.default.post(name: Notification.Name(rawValue: mySpecialNotificationKey), object: errorString)
            }
        })
        task.resume()
    }
    
    // MARK: -
    // MARK: XML parsing methods
    func parseData() {
        // Fix for <?xml version="1.0" encoding="windows-1252"?>
        // This code strips out: encoding="windows-1252"
        let oldStr = NSString(data: responseData, encoding: String.Encoding.windowsCP1252.rawValue)
        
        let newStr = oldStr?.replacingOccurrences(of: "encoding=\"windows-1252\"", with: "")
        let newData = newStr?.data(using: String.Encoding.utf8, allowLossyConversion: true)
        
        xmlParser = XMLParser(data: newData!)
        xmlParser.delegate = self
        xmlParser.shouldResolveExternalEntities = false
        xmlParser.shouldProcessNamespaces = false
        xmlParser.shouldReportNamespacePrefixes = false
        
        if !xmlParser.parse() {
            print("error in parse method call. error=\(String(describing: xmlParser.parserError)) lineNumber =\(xmlParser.lineNumber)")
        }
    }
    
    // MARK: -
    // MARK: NSXMLParserDelegate delegate methods
    
    func parserDidStartDocument(_ parser: XMLParser) {
        print("parser started document")
    }
    
    func parserDidEndDocument(_ parser: XMLParser) {
        DispatchQueue.main.async(execute: {
            // This block will be executed asynchronously on the main thread. Needed because we are in background thread now.
            UIApplication.shared.isNetworkActivityIndicatorVisible = false
            self.feedDelegate.feedFetcher(self, feed: self.itemArray as [Any])
        })
    }
    
    func parser(_ parser: XMLParser, parseErrorOccurred parseError: Error) {
        print("parser error: \(parseError), lineNumber= \(parser.lineNumber), columnNumber: \(parser.columnNumber)")
        let errorString = "Unable to download story feed from web site (Error code \(parseError._code) ) on line \(parser.lineNumber)"
        DispatchQueue.main.async(execute: {
            // This block will be executed asynchronously on the main thread. Needed because we are in background thread now.
            UIApplication.shared.isNetworkActivityIndicatorVisible = false
            NotificationCenter.default.post(name: Notification.Name(rawValue: mySpecialNotificationKey), object: errorString)

        })
    }
    
    func parser(_ parser: XMLParser, didStartElement elementName: String, namespaceURI: String?, qualifiedName qName: String?, attributes attributeDict: [String : String]) {
        
        currentElement = elementName;
        if elementName == "item" {
            // clear out our story item caches...
            currentItemDict = Dictionary<String,String>()
            currentTitle = ""
            currentDate = ""
            currentSummary = ""
            currentLink = ""
            
        }
    }
    
    func parser(_ parser: XMLParser, foundCharacters string: String) {
        // save the characters for the current item
        if currentElement == "title" {
            currentTitle += string
        } else if currentElement == "link" {
            currentLink += string
        } else if currentElement == "description" {
            currentSummary += string
        } else if currentElement == "pubDate" {
            currentDate += string
        }
    }
    
    func parser(_ parser: XMLParser, didEndElement elementName: String, namespaceURI: String?, qualifiedName qName: String?) {
        
        if elementName == "item" {
            // save values to an item, then store that item into the array...
            currentItemDict["title"] = currentTitle.replacingOccurrences(of: "<[^>]+>", with: "", options: .regularExpression, range: nil)
            currentItemDict["link"] = currentLink
            currentItemDict["description"] = currentSummary
            currentItemDict["date"] =  currentDate
            //NSMutableDictionary *tempDict = [self.currentItemDict copy];
            itemArray.append(currentItemDict)
            print("adding item named: \(currentTitle)")
        }
    }
}
