//
//  RootVC.swift
//  Reader
//
//  Created by Bryan French on 8/20/15.
//  Copyright (c) 2015 Bryan French. All rights reserved.
//

//******** NOTE: Plist changes for http vs https and
//******** notification items for displaying error messages

import UIKit

class RootVC: UITableViewController, FeedFetcherDelegate {
    
    let DOCUMENTS_DIR_FILE_NAME  = "feeds.plist"
    let DEFAULT_BUNDLE_FILE_NAME  = "feeds"
    var feedArray : NSMutableArray = []
    var feedFetcher : FeedFetcher?
    var selectedRow = -1
    
    required init(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)!
        title = "RSS Feeds";
        // Load Feeds
        var filePath = ""
        if FileManager.default.fileExists(atPath: dataFilePath()) {
            filePath = dataFilePath()
        } else {
            filePath = Bundle.main.path(forResource: DEFAULT_BUNDLE_FILE_NAME, ofType: "plist")!
        }
        feedArray = NSMutableArray(contentsOfFile: filePath)!
        
        print("feedArray=\(self.feedArray)")

        NotificationCenter.default.addObserver(self, selector: #selector(RootVC.errorInFeed(_:)), name: NSNotification.Name(rawValue: mySpecialNotificationKey), object: nil)

    }
    
    deinit {
        NotificationCenter.default.removeObserver(self)
    }
    
    @objc func errorInFeed(_ notification:Notification)
    {
        let msg = notification.object as! String
        let alert = UIAlertController(title: "Error in getting Feed", message: msg, preferredStyle: .alert)
        
        let OKAction = UIAlertAction(title: "OK", style: .default) { (action) in
            // ...
        }
        alert.addAction(OKAction)
        
        self.present(alert, animated: true) {
            // ignore
        }
        
        
    }


    // MARK: Helper Methods

    // Returns the path to the app's Documents directory.
    func applicationDocumentsDirectory() -> String {
        // Get all 'Documents' directories in this app's sandbox
        // and return the first (and only) Documents directory
        return NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0] 
    }

    // Append my data file name to the end of the Documents directory
    func dataFilePath() -> String {
        return (applicationDocumentsDirectory() as NSString).appendingPathComponent(DOCUMENTS_DIR_FILE_NAME)
    }


    func saveData() {
// TODO:        feedArray.writeToFile(dataFilePath(),atomically:true)
    }

    func getFeed(_ row:Int) {
        UIApplication.shared.isNetworkActivityIndicatorVisible = true
        let dict = feedArray[row] as! Dictionary<String,String>
        let fetcher = FeedFetcher(URL: dict["feedURL"]!)
        fetcher.feedDelegate = self
        feedFetcher = fetcher;
    }

    // MARK: -
    // MARK: FeedFetcherDelegate protocol
    func feedFetcher(_ feedFetcher: FeedFetcher, feed: [Any]) {
        print("got feed: \(feed)")
        
        let articlesTableVC = ArticleTablesVC(style:UITableView.Style.plain)
        articlesTableVC.articles = feed

        navigationController?.pushViewController(articlesTableVC, animated: true)
    }


    override func viewDidLoad() {
        super.viewDidLoad()

    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return feedArray.count
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "FeedCell", for: indexPath) 

        // Configure the cell...
        let dict = feedArray[(indexPath as NSIndexPath).row] as! Dictionary<String,String>
        cell.textLabel!.text = dict["feedTitle"]!
        cell.accessoryType = .disclosureIndicator

        return cell
    }

    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        getFeed((indexPath as NSIndexPath).row)
        selectedRow = (indexPath as NSIndexPath).row
    }

}
