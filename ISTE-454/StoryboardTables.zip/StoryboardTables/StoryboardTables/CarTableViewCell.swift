//
//  CarTableViewCell.swift
//  StoryboardTables
//
//  Created by Student on 11/21/19.
//  Copyright © 2019 Student. All rights reserved.
//

import UIKit

class CarTableViewCell: UITableViewCell {


    @IBOutlet weak var carImage: UIImageView!
    @IBOutlet weak var makeLabel: UILabel!
    @IBOutlet weak var modelLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
