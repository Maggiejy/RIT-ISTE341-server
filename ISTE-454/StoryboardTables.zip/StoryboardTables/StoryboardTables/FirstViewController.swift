//
//  FirstViewController.swift
//  StoryboardTables
//
//  Created by Student on 11/21/19.
//  Copyright © 2019 Student. All rights reserved.
//

import UIKit

class FirstViewController: UITableViewController {
    @IBOutlet weak var firstLable: UILabel!
    @IBOutlet weak var secondLable: UILabel!
    @IBOutlet weak var thirdLable: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        firstLable.text = "First Label"
        secondLable.text = "Second Label"
        thirdLable.text = "Third Label"
    }


}

