//
//  SecondViewController.swift
//  StoryboardTables
//
//  Created by Student on 11/21/19.
//  Copyright © 2019 Student. All rights reserved.
//

import UIKit

class SecondViewController: UITableViewController {
    
    var carImages = ["chevy_volt.jpg","mini_clubman.jpg","toyota_venza.jpg","volvo_s60.jpg","smart_fortwo.jpg"]
    var carMakes = ["Chevy","BMW","Toyota","Volvo","Smart"]
    var carModels = ["Volt","Mini","Venza","S60","Fortwo"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return carModels.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cellIdentifier = "carTableCell"
        let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier, for: indexPath) as! CarTableViewCell
        cell.modelLabel.text = carModels[indexPath.row]
        cell.makeLabel.text = carMakes[indexPath.row]
        cell.carImage.image = UIImage(named:carImages[indexPath.row])
        return cell
    }


}

