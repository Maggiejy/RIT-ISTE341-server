//
//  ViewController.swift
//  TargetActionDemo
//
//  Created by Student on 9/17/19.
//  Copyright © 2019 Student. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate {
    
    let dateFormatter = DateFormatter()
    var date: Date! //until the timer date wont be used //var date:Date = Date()
    var timer: Timer!

    @IBOutlet weak var textName: UITextField!
    
    @IBOutlet weak var clockLabel: UILabel!
    
    @IBOutlet weak var startStopButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //set our style for displaying the date/time
        dateFormatter.timeStyle = .medium
        
    }

    @IBAction func okClicked() {
        textName.resignFirstResponder()
        let str = String(format:"Hello %@",textName.text!)
        //let str = "Hello \(textName.text!)"
        
        let alert = UIAlertController(title: "Greetings!", message: str, preferredStyle: .alert)
        
        //let okAction = UIAlertAction(title: "OK", style: .default, handler: {(action) in //completion handler
        //    //do something
        //})
        //since the handler is the last parameter we could use trailign closure, bring that parameter outside of the parameter list
        //let okAction = UIAlertAction(title: "OK", style: .default) {(action) in
        //    //do something
        //}
        let okAction = UIAlertAction(title: "OK", style: .default,handler: nil)
        alert.addAction(okAction)
        
        present(alert,animated: true)//handler could be added over here too
        
        textName.text = "" //clear the field
        
        
    }
    ///Description
    /// - Parameter sender: UIButton
    @IBAction func clockButtonClicked(_ sender: UIButton) {
        if startStopButton.title(for: .normal) == "Start Clock"{
            //start timer
            timer = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(ViewController.updateTime), userInfo: nil, repeats: true)
            
            //change the button text
            startStopButton.setTitle("Stop Clock", for: .normal)
        } else {
            //stop the timer
            timer.invalidate()
            //change the text otn the button
            startStopButton.setTitle("Start Clock", for: .normal)
        }
    }
    
    //TODO:- Update the timer
    @objc func updateTime(){
        date = Date()
        clockLabel.text = dateFormatter.string(from: date)
        
    }
    
    
    //MARK:- TextFieldDelegate methods
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        //textField.resignFirstResponder()
        okClicked()
        return true
    }
    
    
    
    //FIXME: methods start here
    //#warning("finish this") or #error("message") to come up a real warning or error
}

