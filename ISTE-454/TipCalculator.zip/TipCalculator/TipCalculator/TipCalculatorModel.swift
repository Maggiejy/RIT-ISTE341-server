//
//  TipCalculatorModel.swift
//  TipCalculator
//
//  Created by Student on 9/10/19.
//  Copyright © 2019 Student. All rights reserved.
//

import Foundation
class TipCalculatorModel{
    var total: Double
    var taxPct: Double
    var subTotal: Double{
        get {
            total / (taxPct + 1)
        }
        /*
         set(newSubtotla){
          //some code
         }
         */
    }
    init(total: Double, taxPct: Double){
        self.total = total
        self.taxPct = taxPct
    }
    
    func calcTipWith(tipPct: Double) ->Double{
        subTotal * tipPct
    }
    func returnPossibleTips()->[Int:Double] {
        let possibleTips = [0.15,0.18,0.20]
        var retVal = Dictionary<Int,Double>()
        for possibleTip in possibleTips {
            let intPct = Int(possibleTip*100)
            retVal[intPct] = calcTipWith(tipPct: possibleTip)
        }
        return retVal
    }
}
