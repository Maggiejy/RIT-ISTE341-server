//
//  ViewController.swift
//  TipCalculator
//
//  Created by Student on 9/10/19.
//  Copyright © 2019 Student. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var totalTextField: UITextField!
    @IBOutlet weak var taxPctSlider: UISlider!
    @IBOutlet weak var taxPctLabel: UILabel!
    @IBOutlet weak var resultsTextView: UITextView!
    
    let tipCalc = TipCalculatorModel(total:33.25, taxPct:0.06)
    
    @IBAction func calculateTapped(sender: UIButton) {
        tipCalc.total = Double(totalTextField.text!)! //unwrap the optional variable
        let possibleTips = tipCalc.returnPossibleTips() //return dictionary
        var results = ""
        //for (tipPct, tipValue) in possibleTips {
        //    results += "\(tipPct)%: \(tipValue)\n"
        //}
        var keys = Array(possibleTips.keys) //immutable set to var becomes mutable
        keys.sort()
        for tipPct in keys{
            let tipValue = possibleTips[tipPct]!
            let prettyTipValue = String(format:"%0.2f",tipValue)
            results += "\(tipPct)%: \(prettyTipValue)\n"
        }
        resultsTextView.text = results
        totalTextField.resignFirstResponder() //dismiss keyboard
    }
    
    @IBAction func taxPercentageChanged(sender: UISlider){
        tipCalc.taxPct = Double(taxPctSlider.value)/100.0
        refreshUI()
    }
    
    @IBAction func viewTapped(sender: UIView){
        totalTextField.resignFirstResponder()  //dismiss keyboard
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        refreshUI()
    }
    
    func refreshUI(){
        totalTextField.text = String(format:"%0.2f",tipCalc.total)
        taxPctSlider.value = Float(tipCalc.taxPct)*100.0
        taxPctLabel.text = "Tax Percentage (\(Int(taxPctSlider.value))%)"
        resultsTextView.text = ""
    }


}

