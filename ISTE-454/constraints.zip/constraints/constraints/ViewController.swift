//
//  ViewController.swift
//  constraints
//
//  Created by Student on 10/1/19.
//  Copyright © 2019 Student. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    
    @IBAction func buttonTapped(sender:UIButton){
        if sender.title(for: UIControl.State()) == "X" {
            sender.setTitle("A very long title for this button", for: UIControl.State())
        } else {
            sender.setTitle("X", for: UIControl.State())
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

