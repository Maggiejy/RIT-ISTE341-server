﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using ProductService.Models;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace ProductService.Controllers
{
    [Route("api/[controller]")]
    public class ProductController : Controller
    {
        private List<Product> products = new List<Product>(); 

        public ProductController()
        {
            CreateProducts();
        }
        private void CreateProducts()
        {
            for (int i = 1; i<=5; i++)
            {
                products.Add(new Product() { Name = "Product " + i, Id = i });
            }
        }
        // GET: api/product
        [HttpGet]
        public IEnumerable<Product> GetAll()
        {
            return this.products;
        }

        // GET api/product/5
        [HttpGet("{id}",Name = "GetProduct")]
        public IActionResult GetById(int id)
        {
            Product product = products.Find(x => x.Id == id);
            if (product == null)
            {
                return NotFound();
            }
            return new ObjectResult(product);
        }

        // POST api/product
        [HttpPost]
        public IActionResult Create([FromBody]Product product)
        {
            if (product == null || !ModelState.IsValid)
            {
                return BadRequest();
            }
            //do db insert and validation
            return CreatedAtAction("GetProduct", new { id = product.Id }, product);
        }

        // PUT api/prodcut/5
        [HttpPut("{id}")]
        public IActionResult Update(int id, [FromBody]Product product)
        {
            if (product == null || product.Id != id || !ModelState.IsValid)
            {
                return BadRequest();
            }
            if(!products.Exists(x => x.Id == id))
            {
                return NotFound();
            }
            //validate and update the db
            return new NoContentResult();//return 204 status
        }

        // DELETE api/prodcut/5
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            if (!products.Exists(x => x.Id == id))
            {
                return NotFound();
            }
            //do the delete
            return new NoContentResult();
        }

        //[Route("path")]//[Route("product/{id}/{code=code}")]
        //[HTTPGet]
    }
}
