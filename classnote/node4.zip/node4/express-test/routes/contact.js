var express = require('express');
var router = express.Router();

/* middleware used by every conact route */
router.use(function(req,res,next){
  var method = req.method;
  if(method=="POST"){
    console.log("Body: "+JSON.stringify(req.body));
  } else {
    console.log("Not a POST");
  }
  next();//express doesn't know keep following through
});


/* GET index page */
router.get('/', function(req, res, next) {
  res.render('contact',{title: 'Contact'});
});

/* POST middleware append date */
router.post('/',function(req,res,next){
  const {name,message} = req.body; //destructuring
  const now = new Date();
  req.data = {
    date: now,
    message,
    name
  };
  next();
});



/*POST to the index page */
router.post('/', function(req, res, next) {
  //normally do validation, sanitizaiton, insert into db, etc
  var queryString = 'date='+encodeURIComponent(req.data.date)+
                    '&name='+encodeURIComponent(req.data.name)+
                    '&message='+encodeURIComponent(req.data.message);
  res.redirect('/contact/thanks?'+queryString);
});

/*GET thanks page */
router.get('/thanks', function(req, res, next) {
  console.log(req.query);
  res.render('thanks',{
      title: 'Thanks',
      date: req.query.date,
      name: req.query.name,
      message: req.query.message
  });
});
module.exports = router;