var express = require('express');
var router = express.Router();

var csrf = require('csurf');
var useDomainForCookies = process.env.DOMAIN || false;
var csrfProtection = csrf({
  cookie:{
    key: '_csrf',
    sameSite: true,
    httpOnly: true,
    domain: useDomainForCookies ? host:undefined
  }
});

//receive JSON post
router.post('/', csrfProtection, function(req,res,next){
  console.log('fetch POST', req.body);
  console.log('fetch session', req.session);
  res.send({status: 'ok'});
});
module.exports = router;
