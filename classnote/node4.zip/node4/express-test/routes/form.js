var express = require('express');
var router = express.Router();

var csrf = require('csurf');
var useDomainForCookies = process.env.DOMAIN || false;
var csrfProtection = csrf({
  cookie:{
    key: '_csrf',
    sameSite: true,
    httpOnly: true,
    domain: useDomainForCookies ? host:undefined
  }
});

/* protect from CSRF */
router.get('/', csrfProtection, function(req, res, next) {
  res.render('form', { 
    pageTitle: 'Form',
    csrfToken: req.csrfToken()
  });
});
//receive submission
router.post('/', csrfProtection, function(req,res,next){
  console.log('form submission', req.body);
  res.redirect('/');
});
module.exports = router;
