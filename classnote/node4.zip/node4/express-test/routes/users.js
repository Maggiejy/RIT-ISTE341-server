var express = require('express');
var router = express.Router();

var isLoggedIn = function(req,res,next){
  //using sessions -> req.session.user == 'username' && req.session.admin
  //or passport: req.isAuthenticate()
  var loggedIn = true;
  if(loggedIn){
    return next();
  } else{
    return res.sendStatus(403); //or res.redirect('users/login')
  }
}


/* GET users listing. */
router.get('/', isLoggedIn, function(req, res, next) {
  res.send('respond with a resource');
});

/* Get users and respond with JSON */
router.get('/:id',function(req,res,next){
  console.log("The ID is: "+req.params.id);
  var fakeUser = {
    age: 31,
    name: 'Corey Smith',
    twiter: 'cdawg',
    username: 'csmith'
  };
  res.json(fakeUser);
});
module.exports = router;
